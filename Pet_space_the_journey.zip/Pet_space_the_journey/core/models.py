from django.db import models

#This model created to interpret the database for handling data
class PetStorage(models.Model):
	species = models.CharField(max_length=100)
	pet_name = models.CharField(max_length=100)
	birth_date = models.DateField()
	age = models.IntegerField()
	hight = models.DecimalField(max_digits=5, decimal_places=2)
	weight = models.DecimalField(max_digits=5, decimal_places=2)
	passport_exists = models.BooleanField(default=False)
	passport_num = models.CharField(max_length=100)