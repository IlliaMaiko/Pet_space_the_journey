from django import forms
import datetime

#This form created to collect data for the new pet and check if collected data seems valid
class AddNewPet(forms.Form):
	species = forms.CharField(label= "Species", max_length=100, min_length=1, widget=forms.TextInput)
	pet_name = forms.CharField(label= "Name", max_length=100, min_length=1, widget=forms.TextInput)
	birth_date = forms.DateField(label= "Birth date", widget=forms.DateInput)
	hight = forms.DecimalField(label= "Hight", max_digits=5, decimal_places=2)
	weight = forms.DecimalField(label= "Weight", max_digits=5, decimal_places=2)
	passport_num = forms.CharField(label= "Passport", max_length=100, required=False, widget=forms.TextInput)


	def clean(self):
		date = self.cleaned_data['birth_date']
		if date > datetime.date.today():
			raise forms.ValidationError("The date of birth cannot be in the future!")

		hight = self.cleaned_data['hight']
		if hight < 0:
			raise forms.ValidationError("The hight cannot be less than zero!")

		weight = self.cleaned_data['weight']
		if weight < 0:
			raise forms.ValidationError("The weight cannot be less than zero!")

		return super().clean()


#This form created to collect data for the update on existing pet and check if collected data seems valid
class UpdatePet(forms.Form):
	species = forms.CharField(label= "Species", max_length=100, min_length=1, required=False)
	pet_name = forms.CharField(label= "Name", max_length=100, min_length=1, required=False)
	birth_date = forms.DateField(label= "Birth date", required=False)
	hight = forms.DecimalField(label= "Hight", max_digits=5, decimal_places=2, required=False)
	weight = forms.DecimalField(label= "Weight", max_digits=5, decimal_places=2, required=False)
	passport_num = forms.CharField(label= "Passport", max_length=100, required=False)
	update_pas = forms.BooleanField(label= "Update Passport", required=True)


	def clean(self):
		date = self.cleaned_data['birth_date']
		if not (date is None):
			if date > datetime.date.today():
				raise forms.ValidationError("The date of birth cannot be in the future!")

		hight = self.cleaned_data['hight']
		if not (date is None):
			if hight < 0:
				raise forms.ValidationError("The hight cannot be less than zero!")

		weight = self.cleaned_data['weight']
		if not (date is None):
			if weight < 0:
				raise forms.ValidationError("The weight cannot be less than zero!")

		return super().clean()

#This form created to confirm the intention to delete an element from the database
class DeletePet(forms.Form):
	delete_check = forms.BooleanField(label= "Yes, I want to delete this pet", required=True)

#This form created to collect value for filtering a shown table
class FilterPet(forms.Form):
	species_to_filter = forms.CharField(label= "Filter by species", max_length=100, min_length=1, required=False)
