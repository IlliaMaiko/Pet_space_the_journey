from django.shortcuts import render, redirect
from datetime import date
from .models import PetStorage
from .forms import AddNewPet, UpdatePet, DeletePet, FilterPet

#View for the main page used to show and to filter data from database
def home(request):
	#This part collects all data from local storage
	pet_data = PetStorage.objects.all
	#This part makes distinction between POST and GET
	if request.method == 'POST':
		#This part handls POST to filter database by species
		form = FilterPet(request.POST)

		if form.is_valid():
			species_to_filter = form.cleaned_data["species_to_filter"]
			if species_to_filter != '':
				#This part filter by species and collect data from local database
				pet_data = PetStorage.objects.filter(species = species_to_filter)
		else:
			print(form.errors)
	else:
		form = FilterPet()
	return render(request, 'index.html', {"pet_data": pet_data, "form": form})


#View for the page to add new element in the database
def add_new(request):
	if request.method == 'POST':
		#This part handls POST to collect data, to check if data is valid and to process it
		form = AddNewPet(request.POST)

		if form.is_valid():
			#This part collects data from form
			spec = form.cleaned_data["species"]
			name = form.cleaned_data["pet_name"]
			birth = form.cleaned_data["birth_date"]
			hight = form.cleaned_data["hight"]
			weight = form.cleaned_data["weight"]
			pas = form.cleaned_data["passport_num"]

			#This part creates passport_exists value using passport_num collected from form
			pas_ex = False
			if pas != '':
				pas_ex = True

			#This part creates age value using birth_date collected from form
			today = date.today()
			age = today.year - birth.year - ((today.month, today.day) < (birth.month, birth.day))

			#This part combines data and puts it to the element of PetStorage model
			t = PetStorage(species=spec,pet_name=name,birth_date=birth,age=age,hight=hight,weight=weight,passport_exists=pas_ex,passport_num=pas)
			#This part saves data in local database
			t.save()
		else:
			print(form.errors)
	else:
		form = AddNewPet()
	return render(request, 'add_new.html', {"form": form})


#View for the page to update existing element in the database
def update_data(request, id):
	#This part gets the element from local database by its uid
	pet_data = PetStorage.objects.get(id=id)
	if request.method == 'POST':
		form = UpdatePet(request.POST)

		if form.is_valid():
			#This part updates all data that shoud be updated
			spec = form.cleaned_data["species"]
			if spec != '' and not (date is None):
				pet_data.species = spec
			name = form.cleaned_data["pet_name"]
			if name != '' and not (date is None):
				pet_data.pet_name = name
			birth = form.cleaned_data["birth_date"]
			if date is None:
				pet_data.birth_date = birth
				today = date.today()
				pet_data.age = today.year - birth.year - ((today.month, today.day) < (birth.month, birth.day))
			hight = form.cleaned_data["hight"]
			if hight != 0 and date is None:
				pet_data.hight = hight
			weight = form.cleaned_data["weight"]
			if weight != 0 and date is None:
				pet_data.weight = weight
			update_pas = form.cleaned_data["update_pas"]
			if update_pas:
				pas = form.cleaned_data["passport_num"]
				pet_data.passport_num = pas
				pas_ex = False
				if pas != '':
					pas_ex = True
				pet_data.passport_exists = pas_ex

			#This part saves updated version of thr getted above element in local database
			pet_data.save()
		else:
			print(form.errors)
	else:
		form = UpdatePet()
	return render(request, 'update_data.html', {"form": form, "pet_data": pet_data, "id": id})

#View for the page to update existing element in the database
def delete_pet(request, id):
	#This part gets the element from local database by its uid
	pet_data = PetStorage.objects.get(id=id)
	if request.method == 'POST':
		form = DeletePet(request.POST)

		if form.is_valid():
			#This part deletes element by id from local database
			PetStorage.objects.filter(id=id).delete()
			redirect('/')
		else:
			print(form.errors)
	else:
		form = DeletePet()
	return render(request, 'delete_pet.html', {"pet_data": pet_data, "form": form})