# Pet space project

Made with django and could be lunched with docker using the comands from command.txt.

core file containse all data for the site itself.

Dockerfile, .dockerignore., requirements.txt used to run application with Docker.

pet_storage is a local database.