from django.http import HttpRequest, HttpResponse
from django.shortcuts import render, redirect
from django.views import View
from .models import PetStorage
from .forms import AddNewPet, UpdatePet, DeletePet, FilterPet


# View for the main page used to show and to filter data from database
class HomeView(View):
	def get(self, request: HttpRequest) -> HttpResponse:
		# This part collects all data from local storage
		pet_data = PetStorage.objects.all
		form = FilterPet()
		return render(request, 'index.html', {"pet_data": pet_data, "form": form})

	def post(self, request: HttpRequest) -> HttpResponse:
		form = FilterPet(request.POST)

		if form.is_valid():
			species_to_filter = form.cleaned_data["species_to_filter"]
			if species_to_filter != '':
				# This part filter by species and collect data from local database
				pet_data = PetStorage.objects.filter(species=species_to_filter)
		else:
			print(form.errors)

		return render(request, 'index.html', {"pet_data": pet_data, "form": form})


# View for the page to add new element in the database
class AddNewView(View):
	def get(self, request: HttpRequest) -> HttpResponse:
		form = AddNewPet()
		return render(request, 'add_new.html', {"form": form})

	def post(self, request: HttpRequest) -> HttpResponse:
		form = AddNewPet(request.POST)

		if form.is_valid():
			# This part collects data from form
			spec = form.cleaned_data.get("species", None)
			name = form.cleaned_data.get("pet_name", None)
			birth = form.cleaned_data.get("birth_date", None)
			height = form.cleaned_data.get("height", None)
			weight = form.cleaned_data.get("weight", None)
			pas = form.cleaned_data.get("passport_num", None)

			# This part combines data and puts it to the element of PetStorage model
			t = PetStorage(
					species=spec,
					pet_name=name,
					birth_date=birth,
					height=height,
					weight=weight,
					passport_num=pas
				)
			# This part saves data in local database
			t.save()
			return redirect('/')
		else:
			print(form.errors)
		return render(request, 'add_new.html', {"form": form})


# View for the page to update existing element in the database
class UpdateDataView(View):
	def get(self, request: HttpRequest, id: int) -> HttpResponse:
		# This part gets the element from local database by its uid
		pet_data = PetStorage.objects.get(id=id)
		# This part creates dictionary to pre-fill the form
		data_dict = {
			'species': pet_data.species,
			'pet_name': pet_data.pet_name,
			'birth_date': pet_data.birth_date,
			'height': pet_data.height,
			'weight': pet_data.weight,
			'passport_num': pet_data.passport_num
		}
		form = UpdatePet(data_dict)
		return render(
				request,
				'update_data.html',
				{"form": form, "pet_data": pet_data, "id": id}
			)

	def post(self, request: HttpRequest, id: int) -> HttpResponse:
		pet_data = PetStorage.objects.get(id=id)
		form = UpdatePet(request.POST)

		if form.is_valid():
			# This part updates all data that shoud be updated
			pet_data.species = form.cleaned_data.get("species", None)
			pet_data.pet_name = form.cleaned_data.get("pet_name", None)
			pet_data.birth_date = form.cleaned_data.get("birth_date", None)
			pet_data.height = form.cleaned_data.get("height", None)
			pet_data.weight = form.cleaned_data.get("weight", None)
			update_pas = form.cleaned_data["update_pas"]
			if update_pas:
				pet_data.passport_num = form.cleaned_data.get("passport_num", None)

			# This part saves updated version of the
			# getted above element in local database
			pet_data.save()
		else:
			print(form.errors)

		return render(
				request,
				'update_data.html',
				{"form": form, "pet_data": pet_data, "id": id}
			)


# View for the page to update existing element in the database
class DeletePetView(View):
	def get(self, request: HttpRequest, id: int) -> HttpResponse:
		# This part gets the element from local database by its uid
		pet_data = PetStorage.objects.get(id=id)
		form = DeletePet()
		return render(
				request,
				'delete_pet.html',
				{"pet_data": pet_data, "form": form}
			)

	def post(self, request: HttpRequest, id: int) -> HttpResponse:
		form = DeletePet(request.POST)

		if form.is_valid():
			# This part deletes element by id from local database
			PetStorage.objects.filter(id=id).delete()
			return redirect('/')
		else:
			print(form.errors)
		return render(
				request,
				'delete_pet.html',
				{"form": form}
			)
