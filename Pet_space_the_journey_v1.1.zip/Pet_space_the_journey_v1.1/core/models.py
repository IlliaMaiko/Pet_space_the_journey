from django.db import models
from django.utils import timezone


# This model created to interpret the database for handling data
class PetStorage(models.Model):
	species = models.CharField(max_length=100)
	pet_name = models.CharField(max_length=100)
	birth_date = models.DateField()
	age = models.IntegerField(default=0)
	height = models.DecimalField(max_digits=5, decimal_places=2)
	weight = models.DecimalField(max_digits=5, decimal_places=2)
	passport_exists = models.BooleanField(default=False)
	passport_num = models.CharField(max_length=100)

	@property
	def pet_details(self):
		pet_data = PetStorage.objects.filter(id=self.id)
		if pet_data:
			pet_data.id = self.id
			pet_data.species = self.species
			pet_data.pet_name = self.pet_name
			pet_data.birth_date = self.birth_date
			pet_data.height = self.height
			pet_data.weight = self.weight
			pet_data.passport_num = self.passport_num
			today = timezone.now().date()
			diff_in_years = today.year - self.birth_date.year
			d_m_today = (today.month, today.day)
			d_m_b_day = self.birth_date.month, self.birth_date.day
			past_birth_day = d_m_today < d_m_b_day
			pet_data.age = diff_in_years - past_birth_day
			pet_data.passport_exists = bool(self.passport_num)
			return pet_data
		else:
			return None
