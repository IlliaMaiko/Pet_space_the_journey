from django import forms
from .models import PetStorage
from django.utils.translation import gettext_lazy
from django.utils import timezone


# This form created to collect data for the new pet
# and check if collected data seems valid
class AddNewPet(forms.ModelForm):
	passport_num = forms.CharField(required=False)

	class Meta:
		model = PetStorage
		fields = [
			'species',
			'pet_name',
			'birth_date',
			'height',
			'weight',
			'passport_num'
		]
		labels = {
			'species': gettext_lazy('Species'),
			'pet_name': gettext_lazy('Name'),
			'birth_date': gettext_lazy('Birth date'),
			'height': gettext_lazy('height'),
			'weight': gettext_lazy('Weight'),
			'passport_num': gettext_lazy('Passport'),
		}

	def clean(self) -> PetStorage:
		date = self.cleaned_data.get('birth_date', None)
		if date is not None and date > timezone.now().date():
			raise forms.ValidationError("The date of birth cannot be in the future!")

		height = self.cleaned_data['height']
		if height <= 0:
			raise forms.ValidationError("The height cannot be less or equal to zero!")

		weight = self.cleaned_data['weight']
		if weight <= 0:
			raise forms.ValidationError("The weight cannot be less or equal to zero!")

		return super().clean()


# This form created to collect data for the update on existing pet and
# check if collected data seems valid
class UpdatePet(forms.ModelForm):
	update_pas = forms.BooleanField(required=False)
	passport_num = forms.CharField(required=False)

	class Meta:
		model = PetStorage
		fields = [
			'species',
			'pet_name',
			'birth_date',
			'height',
			'weight',
			'passport_num',
			'update_pas'
		]
		labels = {
			'species': gettext_lazy('Species'),
			'pet_name': gettext_lazy('Name'),
			'birth_date': gettext_lazy('Birth date'),
			'height': gettext_lazy('height'),
			'weight': gettext_lazy('Weight'),
			'passport_num': gettext_lazy('Passport'),
			'update_pas': gettext_lazy('Update Passport'),
		}

	def clean(self) -> PetStorage:
		date = self.cleaned_data.get('birth_date', None)
		if date is not None:
			if date > timezone.now().date():
				raise forms.ValidationError("The date of birth cannot be in the future!")

		height = self.cleaned_data['height']
		if not (date is None):
			if height < 0:
				raise forms.ValidationError("The height cannot be less or equal to zero!")

		weight = self.cleaned_data['weight']
		if not (date is None):
			if weight < 0:
				raise forms.ValidationError("The weight cannot be less or equal to zero!")

		return super().clean()


# This form created to confirm the intention to delete an element
# from the database
class DeletePet(forms.Form):
	delete_check = forms.BooleanField(
			label="Yes, I want to delete this pet",
			required=True
		)


# This form created to collect value for filtering a shown table
class FilterPet(forms.Form):
	species_to_filter = forms.CharField(
			label="Filter by species",
			max_length=100,
			min_length=1,
			required=False
		)
